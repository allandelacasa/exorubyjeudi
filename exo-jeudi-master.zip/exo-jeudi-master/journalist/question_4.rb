$LOAD_PATH.unshift('.')
require "journalist_data.rb"

def getUpperCase
    counter=0
    getJournalists.length.times do |index|
        if getJournalists[index][1]==getJournalists[index][1].upcase 
            counter=counter+1
        end
    end
   
    return counter
 end
puts "APPEL A LA FONCTION POUR TROUVER LE NOMBRE DE LETTRES EN UPPERCASE"
 getUpperCase