$LOAD_PATH.unshift('.')
require "journalist_data.rb"


def sortLength
    orderedArray=getJournalists.sort_by(&:length)
    puts orderedArray
    return orderedArray
 end
puts "APPEL A LA FONCTION POUR TRIER PAR LONGEUR"
 sortLength