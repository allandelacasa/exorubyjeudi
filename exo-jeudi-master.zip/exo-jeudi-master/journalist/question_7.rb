$LOAD_PATH.unshift('.')
require "journalist_data.rb"

def findPos 
    pos=""
    getJournalists.length.times do |index|
        if getJournalists[index]=="@epenser"
            pos=index
        end
    end

    puts pos
    return pos

 end 

 puts "APPEL A LA FONCTION POUR TROUVER LE JOURNALISTS @epenser"

 findPos