$LOAD_PATH.unshift('.')
require "journalist_data.rb"

# Combien y-a-t'il de handle contenant 5 caractères (le @ ne compte pas pour un caractère)
def getFives
    counter=0

    getJournalists.length.times do |index|
        if getJournalists[index].length-1==5
            counter=counter+1
        end
    end
    puts counter
    return counter
 end
 puts "APPEL A LA FONCTION POUR TROUVER LE NOMBRE DE JOURNALISTES AVEC UNE LONGEUR DE 5 CARACTERES (SANS LE @)"
 getFives