$LOAD_PATH.unshift('.')
require "journalist_data.rb"


def sortAlphabetic
    alphabeticArr=getJournalists.sort
    puts alphabeticArr
    return alphabeticArr
 end
puts "APPEL A LA FONCTION POUR TRIER EN ORDRE ALPHABETIQUE"
 sortAlphabetic 
