$LOAD_PATH.unshift('.')
require "journalist_data.rb"

# quelle est le handle le plus court

def getShortest 
    shortest=getJournalists[0].length 
    shortestName=""
    getJournalists.length.times do |index|
        if getJournalists[index].length<shortest
            shortest=getJournalists[index].length
            shortestName=getJournalists[index]
        end
    end
    puts shortestName
    return shortestName
 end
puts "APPEL A LA FONCTION POUR TROUVER LE PLUS COURT"
 getShortest