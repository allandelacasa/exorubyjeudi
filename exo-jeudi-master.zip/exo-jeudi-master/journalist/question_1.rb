
$LOAD_PATH.unshift('.')
require "journalist_data.rb"

# combien de handle dans l'array
puts getJournalists.length