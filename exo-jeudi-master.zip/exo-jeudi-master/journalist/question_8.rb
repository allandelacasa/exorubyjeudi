$LOAD_PATH.unshift('.')
require "journalist_data.rb"

def sortLengthCategory 
    
    arr=[]
    20.times do |i|
        
        obj={}
        counter=0
        getJournalists.length.times do |j|
            if getJournalists[j].length==i+1
                counter=counter+1
                obj["length #{i+1}"]=counter
            
            end
        end
        
        arr.push(obj)
    end
        return arr
    end


    def getArr (arr) 
       
        arr.length.times do |index|
            if arr[index].empty?
                
            else
                puts arr[index]
            end
        end
    end
        

 puts "APPEL A LA FONCTION TRIAGE PAR NOMBRE DE LETTRES"
 sortArr=sortLengthCategory 
 getArr(sortArr)