$LOAD_PATH.unshift('.')
require "crypto_data.rb"

require "number_data.rb"

def combineHash
    hash={}
    getCryptoData.length.times do |index|
        hash[getCryptoData[index]]=getNumberData[index]
    end

   
    return hash
end

def getSmallerThanSixThousand(hash)
    values=[]
    hash.each do |key,value| 
        if value.to_i <6000
            
            values.push({"key":key,"value":value})
        end
    end
   
    return values
end

def getLargest
    getHash=combineHash
    getHashCollection=getSmallerThanSixThousand(getHash)
    max=getHashCollection[0][:value].to_i
    maxInfo={}

    
    getHashCollection.length.times do |index|
        
        if getHashCollection[index][:value].to_i>max
            maxInfo["currency"]=getHashCollection[index][:key]
            maxInfo["value"]=getHashCollection[index][:value]
        end
       
    end
    puts maxInfo
    return maxInfo
     
end

getLargest