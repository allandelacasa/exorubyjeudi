$LOAD_PATH.unshift('.')
require "crypto_data.rb"

require "number_data.rb"

def getSmallestValue
    min=getNumberData[0].to_f
    getNumberData.length.times do |index|
        if getNumberData[index].to_f < min 
            min=getNumberData[index].to_f
        end 
    end

    getMins=getArrayDuplicates(getNumberData,min)

    puts getMins

    return getMins
end



def getArrayDuplicates(arr,min)
    minimums=[]
    arr.length.times do |index|
        if arr[index].to_f==min 
            minimums.push(arr[index].to_f)
        end
    end 
    puts minimums
    return minimums
end

getSmallestValue