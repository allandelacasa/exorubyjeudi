$LOAD_PATH.unshift('.')
require "crypto_data.rb"

require "number_data.rb"

def getGreatestNumber
   
    max=getNumberData[0].to_i
    getNumberData.length.times do |index|
        
        if getNumberData[index].to_i>max 
            max=getNumberData[index].to_i
            
        end
    end 

    
    getMaximums=findDuplicates(getNumberData,max)

    puts getMaximums
    
    
    if getMaximums.length==0
        return max
    else
        return getMaximums
    end
    


    
end


def findDuplicates(arr,max)

    maximums=[]
    arr.length.times do |index|
        if arr[index].to_i == max 
            maximums.push(arr[index].to_i)
        end
    end

    return maximums
end


getGreatestNumber